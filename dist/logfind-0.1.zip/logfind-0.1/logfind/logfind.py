def run():
    raw_input("inside logfind/logfind.py, waiting for input")
run()
