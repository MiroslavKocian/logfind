import logfind
def run2():
    raw_input("inside __init__.py, waiting for input")
  
 
